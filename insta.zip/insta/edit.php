<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="icon" href="angka9.jpg">
    <center>
    <div class = "container">   
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Postingan</title>
    
</head>
<body>
    <h1>Edit Postingan</h1>
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">

        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
        

        <div class="form-group">
      <label for="formFile" class="form-label mt-4">Edit Postingan</label>
      <input class="form-control" type="file"name="foto" id="" required value="<?= $post['foto'] ?>"><br><br>
      <img src="images/<?= $post['foto'] ?>" width="200" alt="" ><br>
    </div><br><br>

         <div class="form-group">
        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Caption"name="caption" id=""  value="<?= $post['caption'] ?>"autocomplete="off">
         </div><br><br>


         <div class="form-group">
        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Lokasi"name="lokasi" id=""  value="<?= $post['lokasi'] ?>"autocomplete="off">
         </div><br><br>

        <input type="submit" value="Update" name="update">
    </form>
    </center>
</body>
</html>

<?php } ?>