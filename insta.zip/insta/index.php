<?php
session_start();
if(!isset($_SESSION['login'])){
  header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        .card-img-top {
            transition: transform 0.3s; 
        }
        .card-img-top:hover {
            transform: scale(1.1);
        }
    </style>
    <title>907Files</title>
    <link rel="icon" href="angka9.jpg">
    <nav class="navbar sticky-top navbar-expand-lg " style="background-color:white;">
  <div class="container-fluid">
    <a class="navbar-brand sticky-top" href="#">907FILES</a>
    <div class="collapse navbar-collapse" id="navbarColor03">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="#">
            <span class="visually-hidden">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
        <li class="nav-item dropdown">
        </li>
      </ul>
      <form class="d-flex">
        
       <!-- Button trigger modal -->
       <span>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
  +
</button>
        <a href="logout.php"class="btn btn-danger"><i class="bi bi-box-arrow-up"></i></a>
        </span>
      </form>

    
    </div>
  </div>
</nav>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css" 
    integrity="sha384-b6lVK+yci+bfDmaY1u0zE8YYJt0TZxLEAFyYSLHId4xoVvsrQu3INevFKo+Xir8e" crossorigin="anonymous">
    
</head>
<body>
<center>
<?php while($post=mysqli_fetch_assoc($query)){?>
        <div class = "container">           
<div class="card mt-4" style="width: 20rem;">

  <img src="images/<?= $post['foto']?>" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><?= $post['caption']?></h5>
    <p class="card-text"><?= $post['lokasi']?></p>    
    <a href="hapus.php?no=<?= $post['no'] ?>"class="btn btn-danger"><i class="bi bi-trash3"></i></a>
    <a href="edit.php?no=<?= $post['no'] ?>"class="btn btn-info"><i class="bi bi-pen-fill"></i></a>
  </div>
</div>
</div>
<?php } ?>
</center>

  <!-- Modal -->
<form action="proses_tambah.php" method="post" enctype="multipart/form-data">
<div class="modal fade" id="modalTambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Tambah Postingan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
     
        <label for="">Foto</label><br>
        <input type="file" name="foto" id="" required><br>
        <label for="">Caption</label><br>
        <input type="text" name="caption" id="" autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" autocomplete="off"><br><br>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Simpan" name="simpan">
          
      </div>
    </div>
  </div>
</div>
</form>
</body>
</html>