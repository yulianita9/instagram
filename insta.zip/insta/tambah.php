<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>907Files</title>
    <link rel="icon" href="angka9.jpg">
    

</head>
<link rel="stylesheet" href="bootstrap.min.css">
<center>
<div class = "container">   
    <h1>Tambah</h1>
    <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">

    <div class="form-group">
      <label for="formFile" class="form-label mt-4">Tambah Postingan</label>
      <input class="form-control" type="file"name="foto" id="" required>
    </div><br><br>

    <div class="form-group">
      <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Caption"name="caption" id="" autocomplete="off">
    </div><br><br>

    <div class="form-group">
      <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Lokasi"name="lokasi" id="" autocomplete="off">
    </div><br><br>

        <button type="submit" name="simpan" class="btn btn-outline-success">Simpan</button>
    </form>
    </center>
</body>
</html>